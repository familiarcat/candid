export default function Missions() {
  return <div className='p-md text-lcars-yellow'>Missions Page Placeholder</div>;
}
