export default function Tasks() {
  return <div className='p-md text-lcars-cyan'>Tasks Page Placeholder</div>;
}
